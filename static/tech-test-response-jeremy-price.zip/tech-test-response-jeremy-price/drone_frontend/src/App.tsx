import { useEffect, useState } from 'react'
import Map, { type Location } from './Map'
import './App.css'

const App = () => {
	// Default to Sydney
	const [location, setLocation] = useState<Location>({
		latitude: -33.947346,
		longitude: 151.179428,
	})
	const [websocket, setWebsocket] = useState<WebSocket | null>(null)

	useEffect(() => {
		const reconnectDelay = 1000 // Start with 1 second

		const connect = () => {
			const ws = new WebSocket('ws://localhost:8080/ws')
			setWebsocket(ws)

			ws.onopen = () => {
				console.log('Web Socket connected.')
			}

			ws.onmessage = (event) => {
				const data = JSON.parse(event.data)
				console.log(data)
				setLocation(data)
			}
			ws.onerror = (error) => {
				console.error('WebSocket error:', error)
				ws.close()
			}
			ws.onclose = () => {
				console.log('WebSocket disconnected')
				console.log('Reconnecting in', reconnectDelay / 1000, 'seconds...')
				setTimeout(connect, reconnectDelay)
			}
		}

		connect()
	}, [])

	const sendPattern = (pattern: string) => {
		const message = { type: 'pattern', pattern: pattern }
		if (websocket) {
			websocket.send(JSON.stringify(message))
		}
	}

	const sendWaypoints = (waypoints: string) => {
		const message = {
			Type: 'waypoints',
			waypoints: [
				{ latitude: -33.947346, longitude: 151.179428 },
				{ latitude: -33.946765, longitude: 151.1796423 },
				{ latitude: -33.9465, longitude: 151.1789 },
			],
		}

		if (websocket) {
			websocket.send(JSON.stringify(message))
		}
	}

	return (
		<div>
			<div
				style={{
					position: 'absolute',
					top: 100,
					left: 11,
					zIndex: 1000,
					backgroundColor: 'white',
					padding: '10px',
					borderBottomRightRadius: '10px',
					boxShadow: '0 2px 6px rgba(0,0,0,0.3)',
					maxWidth: '300px',
				}}
			>
				<div>
					<h2>Drone Tracker</h2>
					<p>
						<strong>Latitude:</strong> {location.latitude.toFixed(6)}
					</p>
					<p>
						<strong>Longitude:</strong> {location.longitude.toFixed(6)}
					</p>
					<hr />
				</div>
				<div>
					<h4>Flight pattern:</h4>
					<button onClick={() => sendPattern('circle')}>Circle</button>
					<button onClick={() => sendPattern('random')}>Random</button>
					<button onClick={() => sendPattern('none')}>None</button>
					<button onClick={() => sendWaypoints('waypoints')}>Waypoints</button>
				</div>
			</div>

			<Map location={location} />
		</div>
	)
}

export default App
