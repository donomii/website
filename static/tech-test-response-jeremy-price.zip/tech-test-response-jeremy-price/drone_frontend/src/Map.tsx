import { MapContainer, TileLayer } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'

import { MarkerLayer, Marker } from 'react-leaflet-marker'
import DroneMarker from './DroneMarker'

export interface Location {
	latitude: number
	longitude: number
}

type Props = { location: Location }

const mapStyles = {
	height: 'calc(100vh)',
}

const Map = ({ location }: Props) => {
	console.log('Drone at', location.latitude, location.longitude)
	return (
		<MapContainer
			center={[location.latitude, location.longitude]}
			zoom={14}
			scrollWheelZoom={true}
			style={mapStyles}
		>
			<TileLayer
				attribution='OpenStreetMap'
				url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
			/>
			<MarkerLayer>
				<Marker position={[location.latitude, location.longitude]}>
					<DroneMarker />
				</Marker>
			</MarkerLayer>
		</MapContainer>
	)
}

export default Map
