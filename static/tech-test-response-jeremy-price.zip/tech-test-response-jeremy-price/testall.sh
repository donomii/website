#!/bin/sh

cd drone_publisher || exit 1
echo "Running tests in drone_publisher..."
go test -v ./...

cd ../drone_subscriber || exit 1
echo "Running tests in drone_subscriber..."
go test -v ./...

cd ..
docker-compose up --build  2> /dev/null > /dev/null &
echo "Starting services with docker-compose..."

# Wait until port 8080 is available
while ! nc -z localhost 8080; do
  echo "Waiting for server to start on port 8080..."
  sleep 2
done

cd test_harness || exit 1
echo "Running tests in test_harness..."
go test -v ./...

pkill -f "docker-compose up --build"
echo "All tests completed."