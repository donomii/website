package main

import (
	"net/http"
	"net/url"
	"testing"
	"time"

	"github.com/gorilla/websocket"
)

func WaitForCondition(t *testing.T, condition func() bool, timeout time.Duration, checkInterval time.Duration, failureMsg string) {
	ticker := time.NewTicker(checkInterval)
	defer ticker.Stop()

	timeoutChan := time.After(timeout)

	for {
		select {
		case <-timeoutChan:
			t.Fatal(failureMsg)
		case <-ticker.C:
			if condition() {
				return
			}
		}
	}
}

func TestClientManager(t *testing.T) {
	cm := ClientManager{}

	if cm.ClientCount() != 0 {
		t.Errorf("Initial client count should be 0")
	}

	// Mock WebSocket connections
	conn1 := &websocket.Conn{}
	conn2 := &websocket.Conn{}

	cm.AddClient(conn1)
	cm.AddClient(conn2)

	if cm.ClientCount() != 2 {
		t.Errorf("Client count should be 2 after adding two clients")
	}

	cm.RemoveClient(conn1)

	if cm.ClientCount() != 1 {
		t.Errorf("Client count should be 1 after removing one client")
	}
}

func TestWebSocket(t *testing.T) {
	var s Connections
	go func() {
		// Setup Redis client and connections manager
		s = Connections{}

		s.clients = ClientManager{}

		// Setup WebSocket endpoint
		http.HandleFunc("/ws", s.handleWebSocket)
		http.ListenAndServe(":8080", nil)
	}()

	if s.clients.ClientCount() != 0 {
		t.Errorf("Initial client count should be 0")
	}
	// Connect to WebSocket server
	u := url.URL{Scheme: "ws", Host: "localhost:8080", Path: "/ws"}
	conn, _, err := websocket.DefaultDialer.Dial(u.String(), nil)
	if err != nil {
		t.Errorf("Failed to connect to WebSocket: %v", err)
	}
	defer conn.Close()
	WaitForCondition(t, func() bool {
		return s.clients.ClientCount() == 1
	}, 5*time.Second, 100*time.Millisecond, "Client count did not update to 1 after connecting")

	// Disconnect
	conn.Close()
	WaitForCondition(t, func() bool {
		return s.clients.ClientCount() == 0
	}, 5*time.Second, 100*time.Millisecond, "Client count did not update to 0 after disconnecting")
}
