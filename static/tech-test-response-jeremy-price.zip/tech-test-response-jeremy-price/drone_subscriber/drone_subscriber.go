package main

import (
	"context"
	"encoding/json"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/go-redis/redis/v8"
	"github.com/gorilla/websocket"
)

/* Drone subscriber

   Listens for drone location updates and relays them to connected WebSocket clients.
   Also listens for flight path and pattern requests from clients and publishes them to Redis.

	 Redis channels:
	    - Subscribes:
		 - drone_coordinates: current drone coordinates
		- Publishes:
		 - flight_path: waypoints to follow
		 - flight_pattern: flight pattern to use
		 - client_state: client connection state updates

   WebSocket messages:
   - From client to server:
	 - pattern: fly the drone in a specific pattern (circle, random, none)
	 - waypoints: loop through a set of waypoints, provided as an array of latitude/longitude pairs
   - From server to client:
	 - location: current drone location (latitude, longitude)

*/

// Upgrade HTTP connections to WebSocket
var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

// Connections struct manages Redis connection and WebSocket clients
type Connections struct {
	redisClient *redis.Client
	clients     ClientManager
}

// Location represents a geographic location with latitude and longitude
type Location struct {
	Latitude  float64 `json:"latitude"`  // Latitude
	Longitude float64 `json:"longitude"` // Longitude
}

// WebSocketMessage is the data from the client to the server
type WebSocketMessage struct {
	Type      string     `json:"type"`      // "pattern" or "waypoints"
	Waypoints []Location `json:"waypoints"` // Array of Locations for the drone to follow
	Pattern   string     `json:"pattern"`   // Pattern for the drone to fly in - "circle", "random", "none"
}

// FlightPathRequest is the message published to Redis for flight path requests
type FlightPathRequest struct {
	Waypoints []Location `json:"waypoints"`
}

// FlightPatternRequest is the message published to Redis for flight pattern requests
type FlightPatternRequest struct {
	Pattern string `json:"pattern"`
}

// ClientManager manages WebSocket clients and broadcasts messages to them
type ClientManager struct {
	clients     sync.Map
	redisClient *redis.Client
	removeLock  sync.Mutex
}

// Start managing a client, and relaying messages to it
//
// There is a channel for each client, and messages are sent to each client via that channel
func (cm *ClientManager) AddClient(conn *websocket.Conn) {
	ch := make(chan interface{}, 10)

	// Start the client writer thread
	go func() {
		for msg := range ch {
			// Send the message to the client
			err := conn.WriteJSON(msg)
			if err != nil {
				log.Printf("Error writing to client %v: %v", conn.RemoteAddr(), err)
				return
			}
		}

	}()
	cm.clients.Store(conn, ch)
	if cm.redisClient != nil {
		cm.redisClient.Publish(context.Background(), "client_state", `{"state":"connected"}`)
	}
}

// Stop managing a client, close its channel and connection, and alert the publisher
func (cm *ClientManager) RemoveClient(conn *websocket.Conn) {
	cm.removeLock.Lock()
	defer cm.removeLock.Unlock()
	value, ok := cm.clients.Load(conn)
	if ok {
		close(value.(chan interface{}))
	}
	cm.clients.Delete(conn)
	if conn.UnderlyingConn() != nil {
		conn.Close()
	}
	if cm.redisClient != nil {
		cm.redisClient.Publish(context.Background(), "client_state", `{"state":"disconnected"}`)
	}
}

// Broadcast a message to all connected clients
func (cm *ClientManager) Broadcast(message interface{}) {
	cm.clients.Range(func(key, value interface{}) bool {
		ch := value.(chan interface{})
		select {
		case ch <- message:
		case <-time.After(200 * time.Millisecond):
			log.Printf("Client too slow, dropping client: %v", key.(*websocket.Conn).RemoteAddr())
			cm.RemoveClient(key.(*websocket.Conn))
		}
		return true
	})
}

// Get the current number of connected clients
func (cm *ClientManager) ClientCount() int {
	count := 0
	cm.clients.Range(func(key, value interface{}) bool {
		count++
		return true
	})
	return count
}

func main() {

	// Setup Redis client and connections manager
	s := Connections{
		redisClient: redis.NewClient(&redis.Options{
			Addr: "redis:6379", // Replace with your Redis server address
		}),
	}
	s.clients = ClientManager{redisClient: s.redisClient}

	// Start subscribing to Redis channels
	go s.subscribeToLocationUpdates()

	// Setup WebSocket endpoint
	http.HandleFunc("/ws", s.handleWebSocket)
	http.ListenAndServe(":8080", nil)

}

// Reads location updates from Redis and broadcasts them to all connected WebSocket clients, via the client manager
func (s *Connections) subscribeToLocationUpdates() {
	// Subscribe to the "drone_coordinates" channel
	subscriber := s.redisClient.Subscribe(context.Background(), "drone_coordinates")
	defer subscriber.Close()

	// Listen for messages and broadcast them to clients
	for msg := range subscriber.Channel() {
		locationMsg := Location{}
		err := json.Unmarshal([]byte(msg.Payload), &locationMsg)
		if err != nil {
			continue
		}

		s.clients.Broadcast(locationMsg)
	}
}

// Accept WebSocket connections from clients, register them in the client manager, and handle messages from them on a thread
func (s *Connections) handleWebSocket(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}

	// Start the networking
	s.clients.AddClient(conn)
	go s.readClientMessages(conn)
}

// Read messages from a WebSocket client and publish them to Redis
func (s *Connections) readClientMessages(conn *websocket.Conn) {
	defer conn.Close()
	for {
		var wsm WebSocketMessage

		// Read  from client
		err := conn.ReadJSON(&wsm)
		if err != nil {
			s.clients.RemoveClient(conn)
			break
		}

		// Send to Redis
		switch wsm.Type {
		case "pattern":
			// Fly the drone in a specific pattern
			patternMsg := FlightPatternRequest{Pattern: wsm.Pattern}
			data, err := json.Marshal(patternMsg)
			if err != nil {
				continue //Would log in prod
			}
			s.redisClient.Publish(context.Background(), "flight_pattern", data)
		case "waypoints":
			// Loop through a set of waypoints, provided as an array of latitude/longitude pairs
			pathMsg := FlightPathRequest{Waypoints: wsm.Waypoints}
			data, err := json.Marshal(pathMsg)
			if err != nil {
				continue //Would log in prod
			}
			s.redisClient.Publish(context.Background(), "flight_path", data)
		default:
			// Unknown message type, probably a control message, ignore
		}
	}
}
