package main

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"math/rand"
	"sync"
	"sync/atomic"
	"time"

	"github.com/go-redis/redis/v8"
)

/* Drone publisher

   Simulates a drone.  Publishes location, listens for flight path and patterns, and client connection state.

     Redis channels:
   - Publishes:
	 - drone_coordinates: current drone coordinates
   - Subscribes:
	 - flight_path: waypoints to follow
	 - flight_pattern: flight pattern to use
	 - client_state: client connection state updates

   Flight patterns:
   - circle: circles around the initial location
   - random: random walk within a small area
   - none: stays in the same location

   Flight path:
   - waypoints: follows a series of waypoints in order, looping back to the start

   Listens for client connection state updates to track number of connected clients.
   Only publishes location when there is at least one connected client.
*/

type Location struct {
	Latitude  float64 `json:"latitude"`  //Latitude
	Longitude float64 `json:"longitude"` //Longitude
}

type Drone struct {
	Location          Location      //Current Location
	waypoints         []Location    //Waypoints to follow
	currentWaypoint   int           //Index of the current waypoint
	pattern           string        //Flight pattern: "circle", "random", "waypoints"
	redisClient       *redis.Client //Redis client
	step              int           //Step counter for circular movement
	clientNumber      atomic.Int64  //Number of connected clients
	lock              sync.Mutex    //Mutex for synchronizing access to waypoints and pattern
	flightPathChan    chan FlightPathRequest
	flightPatternChan chan FlightPatternRequest
	clientStateChan   chan ClientStateRequest
}

type FlightPathRequest struct {
	Waypoints []Location `json:"waypoints"` //Array of waypoints to be followed in waypoints mode
}
type FlightPatternRequest struct {
	Pattern string `json:"pattern"` //Flight pattern: "circle", "random", "waypoints"
}
type ClientStateRequest struct {
	State string `json:"state"`
}

func main() {
	rdb := redis.NewClient(&redis.Options{
		Addr: "redis:6379", // Replace with your Redis server address
	})

	drone := Drone{
		Location:        Location{Latitude: -33.947346, Longitude: 151.179428}, // Sydney Airport
		waypoints:       []Location{},
		currentWaypoint: 0,
		redisClient:     rdb,
		pattern:         "random",
	}

	drone.subscribe()
	drone.publish()
}

// Subscribe to Redis channels for flight path, pattern, and client state, and monitor them in separate threads
func (d *Drone) subscribe() {
	d.flightPathChan = make(chan FlightPathRequest)
	d.flightPatternChan = make(chan FlightPatternRequest)
	d.clientStateChan = make(chan ClientStateRequest)

	// Start workers to update state
	go d.monitorFlightPath()
	go d.monitorFlightPattern()
	go d.monitorClientState()

	// Start subscribers to Redis channels
	go d.subscribeToFlightPath()
	go d.subscribeToPatterns()
	go d.subscribeToClients()

}

// Subscribe to flight path updates
func (d *Drone) subscribeToFlightPath() {
	subscriber := d.redisClient.Subscribe(context.Background(), "flight_path")
	// The library automatically handles resubscribing if the connection is lost
	for {
		for msg := range subscriber.Channel() {
			var req FlightPathRequest
			err := json.Unmarshal([]byte(msg.Payload), &req)
			if err != nil {
				fmt.Println("Error unmarshaling flight path request:", err)
				continue
			}
			d.flightPathChan <- req
		}
		time.Sleep(100 * time.Millisecond) //Prevent busy loop if subscription fails
	}
}

func (d *Drone) monitorFlightPath() {
	for req := range d.flightPathChan {

		d.lock.Lock()
		d.waypoints = req.Waypoints
		d.currentWaypoint = 0
		d.pattern = "waypoints"
		d.lock.Unlock()
	}
}

// Subscribe to flight pattern updates, read them, and send them to the monitor channel
func (d *Drone) subscribeToPatterns() {
	subscriber := d.redisClient.Subscribe(context.Background(), "flight_pattern")
	for {
		for msg := range subscriber.Channel() {
			var req FlightPatternRequest
			err := json.Unmarshal([]byte(msg.Payload), &req)
			if err != nil {
				fmt.Println("Error unmarshaling flight pattern request:", err)
				continue
			}
			d.flightPatternChan <- req
		}
		time.Sleep(100 * time.Millisecond) //Prevent busy loop if subscription fails
	}
}

// Monitor flight pattern requests and update the drone's flight pattern accordingly
func (d *Drone) monitorFlightPattern() {
	for req := range d.flightPatternChan {

		d.lock.Lock()
		d.pattern = req.Pattern
		d.lock.Unlock()
	}
}

// Subscribe to client connection state updates
func (d *Drone) subscribeToClients() {
	subscriber := d.redisClient.Subscribe(context.Background(), "client_state")
	for {
		for msg := range subscriber.Channel() {
			var req ClientStateRequest
			err := json.Unmarshal([]byte(msg.Payload), &req)
			if err != nil {
				fmt.Println("Error unmarshaling client state request:", err)
				continue
			}
			d.clientStateChan <- req
		}
		time.Sleep(100 * time.Millisecond) //Prevent busy loop if subscription fails
	}
}

// Monitor client connection state updates and adjust the connected client count
func (d *Drone) monitorClientState() {
	for req := range d.clientStateChan {
		if req.State == "connected" {
			d.clientNumber.Add(1)
		} else if req.State == "disconnected" {
			d.clientNumber.Add(-1)
		}

	}
}

// Publish drone coordinates to Redis at regular intervals, if there are connected clients
func (d *Drone) publish() {
	for {
		time.Sleep(200 * time.Millisecond)
		if d.clientCount() == 0 {
			// No clients connected, wait and check again
			continue
		}
		// Publish current drone coordinates to Redis
		coordinates, err := json.Marshal(d.DroneCoordinates())
		if err != nil {
			continue
		}
		err = d.redisClient.Publish(context.Background(), "drone_coordinates", coordinates).Err()
		if err != nil {
			fmt.Println("Error publishing drone coordinates:", err)
		}
	}
}

// Get the current number of connected clients
func (d *Drone) clientCount() int64 {
	c := d.clientNumber.Load()
	return c
}

// Calculate the next drone coordinates based on the current flight pattern
func (d *Drone) DroneCoordinates() Location {
	d.lock.Lock()
	defer d.lock.Unlock()

	// Calculate next location based on pattern
	switch d.pattern {
	case "circle":
		// Circlework around the initial location
		loc := Location{
			Latitude:  d.Location.Latitude + 0.003*math.Sin(float64(d.step)*math.Pi/10),
			Longitude: d.Location.Longitude + 0.003*math.Cos(float64(d.step)*math.Pi/10),
		}
		d.step++
		return loc

	case "random":
		location := Location{}
		// Random walk within a small area
		location.Latitude = d.Location.Latitude + rand.Float64()*0.001
		location.Longitude = d.Location.Longitude + rand.Float64()*0.001

		return location
	case "waypoints":
		// Step through the waypoints in order, looping back to the start
		// If no waypoints are set, stay in the same location
		if len(d.waypoints) == 0 {
			return d.Location
		}
		d.currentWaypoint = (d.currentWaypoint + 1) % len(d.waypoints)
		return d.waypoints[d.currentWaypoint]
	default:
		return d.Location
	}

}
