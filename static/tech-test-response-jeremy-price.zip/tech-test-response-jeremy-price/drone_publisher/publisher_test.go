package main

import (
	"testing"
	"time"
)

func WaitForCondition(t *testing.T, condition func() bool, timeout time.Duration, checkInterval time.Duration, failureMsg string) {
	ticker := time.NewTicker(checkInterval)
	defer ticker.Stop()

	timeoutChan := time.After(timeout)

	for {
		select {
		case <-timeoutChan:
			t.Fatal(failureMsg)
		case <-ticker.C:
			if condition() {
				return
			}
		}
	}
}

func TestDroneChannels(t *testing.T) {
	drone := Drone{
		Location:        Location{Latitude: -33.947346, Longitude: 151.179428}, // Sydney Airport
		waypoints:       []Location{},
		currentWaypoint: 0,
		redisClient:     nil,
		pattern:         "random",
	}

	drone.flightPathChan = make(chan FlightPathRequest)
	drone.flightPatternChan = make(chan FlightPatternRequest)
	drone.clientStateChan = make(chan ClientStateRequest)

	go drone.monitorFlightPath()
	go drone.monitorFlightPattern()
	go drone.monitorClientState()

	count := drone.clientNumber.Load()
	if count != 0 {
		t.Errorf("Initial client count should be 0, got %d", count)
	}

	drone.clientStateChan <- ClientStateRequest{State: "connected"}
	WaitForCondition(t, func() bool {
		count = drone.clientNumber.Load()
		return count == 1
	}, 2*time.Second, 100*time.Millisecond, "Client count did not update to 1 after connecting")

	drone.clientStateChan <- ClientStateRequest{State: "disconnected"}
	WaitForCondition(t, func() bool {
		count = drone.clientNumber.Load()
		return count == 0
	}, 2*time.Second, 100*time.Millisecond, "Client count did not update to 0 after disconnecting")

	drone.flightPatternChan <- FlightPatternRequest{Pattern: "circle"}
	WaitForCondition(t, func() bool {
		drone.lock.Lock()
		pattern := drone.pattern
		drone.lock.Unlock()
		return pattern == "circle"
	}, 2*time.Second, 100*time.Millisecond, "Flight pattern did not update to 'circle'")

	drone.flightPatternChan <- FlightPatternRequest{Pattern: "random"}
	WaitForCondition(t, func() bool {
		drone.lock.Lock()
		pattern := drone.pattern
		drone.lock.Unlock()
		return pattern == "random"
	}, 2*time.Second, 100*time.Millisecond, "Flight pattern did not update to 'random'")

	waypoints := []Location{
		{Latitude: -33.8688, Longitude: 151.2093}, // Sydney
		{Latitude: -37.8136, Longitude: 144.9631}, // Melbourne
	}
	drone.flightPathChan <- FlightPathRequest{Waypoints: waypoints}
	WaitForCondition(t, func() bool {
		drone.lock.Lock()
		wp := drone.waypoints
		drone.lock.Unlock()
		if len(wp) != len(waypoints) {
			return false
		}
		for i := range wp {
			if wp[i] != waypoints[i] {
				return false
			}
		}
		return true
	}, 2*time.Second, 100*time.Millisecond, "Waypoints did not update correctly")
}

func TestPathGenerator(t *testing.T) {
	drone := Drone{
		Location:        Location{Latitude: -33.947346, Longitude: 151.179428}, // Sydney Airport
		waypoints:       []Location{},
		currentWaypoint: 0,
		redisClient:     nil,
		pattern:         "random",
	}

	drone.pattern = "waypoints"
	drone.waypoints = []Location{
		{Latitude: -33.8688, Longitude: 151.2093}, // Sydney
		{Latitude: -37.8136, Longitude: 144.9631}, // Melbourne
	}
	drone.currentWaypoint = 0

	loc := drone.DroneCoordinates()
	if loc != drone.waypoints[1] {
		t.Errorf("Expected first waypoint, got %+v", loc)
	}

	loc = drone.DroneCoordinates()
	if loc != drone.waypoints[0] {
		t.Errorf("Expected second waypoint, got %+v", loc)
	}

	loc = drone.DroneCoordinates()
	if loc != drone.waypoints[1] {
		t.Errorf("Expected loop back to first waypoint, got %+v", loc)
	}

	drone.pattern = "random"
	loc = drone.DroneCoordinates()
	if loc.Latitude < -34.947346 || loc.Latitude > -32.947346 || loc.Longitude < 150.179428 || loc.Longitude > 152.179428 {
		t.Errorf("Random location out of bounds: %+v", loc)
	}
}
