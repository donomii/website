package main

import (
	"fmt"
	"net/url"
	"sync"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// drone_publisher
type ClientStateRequest struct {
	State string `json:"state"`
}

// Test configuration
type TestConfig struct {
	RedisAddr       string
	SubscriberAddr  string
	TestTimeout     time.Duration
	MessageInterval time.Duration
}

// Location represents a geographic location with latitude and longitude
type Location struct {
	Latitude  float64 `json:"latitude"`  // Latitude
	Longitude float64 `json:"longitude"` // Longitude
}

// WebSocketMessage is the data from the client to the server
type WebSocketMessage struct {
	Type      string     `json:"type"`      // "pattern" or "waypoints"
	Waypoints []Location `json:"waypoints"` // Array of Locations for the drone to follow
	Pattern   string     `json:"pattern"`   // Pattern for the drone to fly in - "circle", "random", "none"
}

// FlightPathRequest is the message published to Redis for flight path requests
type FlightPathRequest struct {
	Waypoints []Location `json:"waypoints"`
}

// FlightPatternRequest is the message published to Redis for flight pattern requests
type FlightPatternRequest struct {
	Pattern string `json:"pattern"`
}

func connectWebSocket(t *testing.T) *websocket.Conn {
	u := url.URL{Scheme: "ws", Host: "localhost:8080", Path: "/ws"}
	dialer := websocket.DefaultDialer
	dialer.HandshakeTimeout = 5 * time.Second
	conn, _, err := dialer.Dial(u.String(), nil)
	require.NoError(t, err, "Failed to connect to WebSocket")
	if err != nil {
		t.Fatalf("Failed to connect to WebSocket: %v", err)
	}
	return conn
}

func printTestStep(step string) {
	fmt.Printf("→ %s\n", step)
}

func printMessage(direction, msgType, content string) {
	fmt.Printf("  [%s] %s: %s\n", direction, msgType, content)
}

func WaitForCondition(t *testing.T, condition func() bool, timeout time.Duration, checkInterval time.Duration, failureMsg string) {
	ticker := time.NewTicker(checkInterval)
	defer ticker.Stop()

	timeoutChan := time.After(timeout)

	for {
		select {
		case <-timeoutChan:
			t.Fatal(failureMsg)
		case <-ticker.C:
			if condition() {
				return
			}
		}
	}
}

func TestDroneCoordinateStreaming(t *testing.T) {
	printTestStep("Testing drone coordinate streaming")

	conn := connectWebSocket(t)
	defer conn.Close()

	coordinates := make(chan Location, 10)
	errors := make(chan error, 1)

	go func() {
		conn.SetReadDeadline(time.Now().Add(2 * time.Second))
		for {
			var location Location
			err := conn.ReadJSON(&location)
			if err != nil {
				errors <- err
				return
			}
			coordinates <- location
		}
	}()

	conn.WriteJSON(WebSocketMessage{Type: "waypoints", Waypoints: []Location{{Latitude: 123.456, Longitude: 78.90}}})
	WaitForCondition(t, func() bool {
		// Receive on WebSocket
		select {
		case receivedLoc := <-coordinates:
			if receivedLoc.Latitude == 123.456 || receivedLoc.Longitude == 78.90 {
				return true
			}
		case err := <-errors:
			t.Logf("WebSocket error: %v", err)
			return false
		case <-time.After(1 * time.Second):
			t.Logf("Timeout waiting for coordinate message")
		}

		return false
	}, 10*time.Second, 100*time.Millisecond, "Did not receive expected coordinates from WebSocket")
}

func TestMultipleClients(t *testing.T) {
	printTestStep("Testing multiple WebSocket clients receiving the same coordinates")

	numClients := 3
	clients := make([]*websocket.Conn, numClients)
	coordinateChannels := make([]chan Location, numClients)

	conn := connectWebSocket(t)
	defer conn.Close()

	testLocation := Location{Latitude: 123.456, Longitude: 78.90}
	conn.WriteJSON(WebSocketMessage{Type: "waypoints", Waypoints: []Location{testLocation}})

	// Connect multiple clients
	for i := 0; i < numClients; i++ {
		clients[i] = connectWebSocket(t)
		defer clients[i].Close()
		coordinateChannels[i] = make(chan Location, 10)

		go func(clientIndex int) {
			conn := clients[clientIndex]
			ch := coordinateChannels[clientIndex]
			conn.SetReadDeadline(time.Now().Add(5 * time.Second))
			for {
				var location Location
				err := conn.ReadJSON(&location)
				if err != nil {
					return
				}
				ch <- location
			}
		}(i)
	}

	// Verify all clients receive the same update
	var wg sync.WaitGroup
	wg.Add(numClients)

	for i := 0; i < numClients; i++ {
		go func(clientIndex int) {
			defer wg.Done()
			select {
			case receivedLoc := <-coordinateChannels[clientIndex]:
				assert.Equal(t, testLocation.Latitude, receivedLoc.Latitude,
					fmt.Sprintf("Client %d latitude mismatch", clientIndex))
				assert.Equal(t, testLocation.Longitude, receivedLoc.Longitude,
					fmt.Sprintf("Client %d longitude mismatch", clientIndex))
				printMessage("RECEIVED", fmt.Sprintf("Client %d", clientIndex),
					fmt.Sprintf("Coordinates: (%.6f, %.6f)", receivedLoc.Latitude, receivedLoc.Longitude))
			case <-time.After(5 * time.Second):
				t.Errorf("Client %d timeout waiting for coordinates", clientIndex)
			}
		}(i)
	}

	wg.Wait()
}
