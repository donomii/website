(function () {
  window.CotBRuntime = window.CotBRuntime || {};
  window.CotBRuntime.installInput = function (context) {
    with (context) {
      const gamepadActions = [[0, "interact"], [1, "wait"], [2, "attack"], [3, "pickup"],
        [4, "signature"], [5, "ultimate"], [6, "recover"],
        [12, "moveForward"], [13, "moveBack"], [14, "turnLeft"], [15, "turnRight"]];
      let gamepadState = null;
      let gamepadPack = null;

      function standardStickAction(axes) {
        const [strafe = 0, travel = 0, turn = 0] = axes;
        if (Math.max(Math.abs(strafe), Math.abs(travel)) >= 0.55) {
          return Math.abs(travel) >= Math.abs(strafe)
            ? (travel < 0 ? "moveForward" : "moveBack")
            : (strafe < 0 ? "moveLeft" : "moveRight");
        } else {
          return Math.abs(turn) >= 0.55 ? (turn < 0 ? "turnLeft" : "turnRight") : null;
        }
      }

      function gamepadModal(modal, pressed) {
        const visibleControls = () => [...modal.querySelectorAll(
          "button:not(:disabled), a[href], select:not([multiple]):not(:disabled), input[type=checkbox]:not(:disabled)"
        )]
          .filter(control => control.getClientRects().length);
        const controls = visibleControls();
        const current = controls.indexOf(document.activeElement);
        const focused = controls[current];
        const horizontal = Number(Boolean(pressed(15))) - Number(Boolean(pressed(14)));
        if (pressed(1) && modal.id !== "characterCreateModal" && modal.id !== "endModal") {
          hideAllModals();
        } else if (horizontal && focused?.tagName === "SELECT") {
          const options = [...focused.options].filter(option => !option.matches(":disabled"));
          const selected = options.findIndex(option => option.index === focused.selectedIndex);
          const next = selected < 0 && horizontal < 0 ? options.length - 1
            : (selected + horizontal + options.length) % options.length;
          const option = options[next];
          if (option && option.index !== focused.selectedIndex) {
            focused.selectedIndex = option.index;
            focused.dispatchEvent(new Event("change", { bubbles: true }));
          }
        } else if (controls.length && (pressed(12) || horizontal < 0)) {
          controls[current <= 0 ? controls.length - 1 : current - 1].focus();
        } else if (controls.length && (pressed(13) || horizontal > 0)) {
          controls[(current + 1) % controls.length].focus();
        } else if (pressed(0) && focused?.tagName !== "SELECT") {
          focused?.click();
        }
        // Changing a class or portrait can rebuild the party controls.
        if (focused?.isConnected === false && document.querySelector(".modal:not(.hidden)") === modal) {
          visibleControls()[current]?.focus();
        }
      }

      function gamepadInventory(pressed) {
        if (gamepadPack && !gamepadPack.open) gamepadPack = null;
        const toggle = pressed(8);
        if (!gamepadPack && !toggle) return false;
        const back = pressed(1);
        const use = pressed(0);
        const previous = pressed(12) || pressed(14);
        const next = pressed(13) || pressed(15);
        if (!toggle && !back && !use && !previous && !next) return true;
        const inventory = document.getElementById("inventory");
        const panel = inventory?.closest("details");
        if (!panel) return false;

        const items = () => [...inventory.querySelectorAll("button[data-item]:not(:disabled)")];
        const heading = panel.querySelector("summary");
        if (!gamepadPack) {
          gamepadPack = panel;
          panel.open = true;
          (items()[0] || heading).focus();
        } else if (toggle || back) {
          panel.open = false;
          heading.focus();
          gamepadPack = null;
        } else {
          const controls = items();
          const current = controls.indexOf(document.activeElement);
          if (controls.length && previous) {
            controls[current <= 0 ? controls.length - 1 : current - 1].focus();
          } else if (controls.length && next) {
            controls[(current + 1) % controls.length].focus();
          } else if (use && controls[current]) {
            controls[current].click();
            if (!document.querySelector(".modal:not(.hidden)")) {
              const remaining = items();
              (remaining[Math.min(current, remaining.length - 1)] || heading).focus();
            }
          }
        }
        return true;
      }

      function pollStandardGamepad(immersive = false, active = true) {
        let pad = null;
        if (active && (immersive || (!document.hidden && document.hasFocus()))) {
          try {
            pad = Array.from(window.navigator.getGamepads?.() || []).find(candidate => candidate?.connected && candidate.mapping === "standard");
          } catch (error) {
            if (error.name !== "SecurityError") throw error;
          }
        }
        if (!pad) {
          gamepadState = null;
          return null;
        }
        const buttons = Array.from(pad.buttons, button => button.pressed);
        const previous = gamepadState?.index === pad.index && gamepadState.id === pad.id && gamepadState.immersive === immersive
          ? gamepadState : null;
        const stickAction = standardStickAction(pad.axes);
        const centered = pad.axes.slice(0, 3).every(value => Math.abs(value) <= 0.3);
        const stickArmed = centered || (previous?.stickArmed && !stickAction);
        gamepadState = { index: pad.index, id: pad.id, immersive, buttons, stickArmed };
        if (!previous) return null;

        const pressed = index => buttons[index] && !previous.buttons[index];
        const modal = immersive ? null : document.querySelector(".modal:not(.hidden)");
        if (modal) {
          gamepadModal(modal, pressed);
          return null;
        } else if (!immersive && pressed(9)) {
          const guide = document.getElementById("gamepadHelp");
          if (guide) guide.open = true;
          toggleHelpModal();
          return null;
        } else if (!immersive && gamepadInventory(pressed)) {
          return null;
        } else {
          const buttonAction = gamepadActions.find(([index]) => pressed(index));
          return buttonAction?.[1] || (previous.stickArmed ? stickAction : null);
        }
      }

      function bindStandardGamepad() {
        if (typeof window.navigator.getGamepads !== "function") return;
        const reset = () => { gamepadState = null; };
        window.addEventListener("gamepadconnected", reset);
        window.addEventListener("gamepaddisconnected", reset);
        window.addEventListener("blur", reset);
        const tick = () => {
          if (!context.vrIsPresenting()) {
            const action = pollStandardGamepad();
            if (action) handleAction(action);
          }
          window.requestAnimationFrame(tick);
        };
        window.requestAnimationFrame(tick);
      }

      function dispatchUiAction(action) {
        if (action === "help") {
          toggleHelpModal();
          return true;
        }
        if (action === "legend") {
          showModal("legendModal");
          return true;
        }
        if (action === "settings") {
          showModal("settingsModal");
          return true;
        }
        if (action === "achievements") {
          showModal("achievementsModal");
          return true;
        }
        if (action === "history") {
          showModal("historyModal");
          return true;
        }
        if (action === "character") {
          showModal("characterModal");
          return true;
        }
        if (action === "talents") {
          showModal("talentsModal");
          return true;
        }
        if (action === "markers") {
          showModal("markersModal");
          return true;
        }
        if (action === "saveSlots") {
          showModal("saveSlotsModal");
          return true;
        }
        if (action === "moreActions") {
          showModal("moreActionsModal");
          return true;
        }
        if (action === "bestiary") {
          showModal("bestiaryModal");
          return true;
        }
        if (action === "stats") {
          showModal("statsModal");
          return true;
        }
        if (action === "quests") {
          showModal("questsModal");
          return true;
        }
        if (action === "newRun") {
          if (typeof newRun === "function") newRun();
          return true;
        }
        if (action === "confirmNewRun") {
          if (typeof window?.confirm === "function") {
            if (!window.confirm("Wipe your save and start a new run?")) return true;
          }
          if (typeof newRun === "function") newRun();
          return true;
        }
        return false;
      }

      function bindSidebarAccordion() {
        const sections = document.querySelectorAll(".side-panel details[data-sidebar-section]");
        sections.forEach((section) => {
          section.addEventListener("toggle", () => {
            if (!section.open) return;
            sections.forEach((other) => {
              if (other !== section) other.open = false;
            });
          });
        });
      }

      function bindInput() {
        bindSidebarAccordion();
        bindStandardGamepad();
        document.querySelectorAll(".command-strip, .accordion-actions, .more-actions-grid, #settingsModal .modal-actions, #characterCreateModal .modal-actions").forEach((container) => {
          container.addEventListener("click", (event) => {
            const button = event.target.closest("button[data-action]");
            if (!button) return;
            const action = button.dataset.action;
            if (dispatchUiAction(action)) return;
            handleAction(action);
          });
        });

        els.inventory.addEventListener("click", (event) => {
          const button = event.target.closest("button[data-item]");
          if (button) useItem(button.dataset.item);
        });

        document.querySelectorAll("[data-modal-close]").forEach((node) => {
          node.addEventListener("click", () => hideAllModals());
        });
        if (els.endModalNewRun?.addEventListener) {
          els.endModalNewRun.addEventListener("click", () => {
            if (typeof newRun === "function") newRun();
          });
        }
        const shareBtn = document.getElementById("endModalShare");
        if (shareBtn?.addEventListener) {
          shareBtn.addEventListener("click", () => {
            if (typeof copyRunSummary === "function") copyRunSummary();
          });
        }
        if (els.shopList?.addEventListener) {
          els.shopList.addEventListener("click", (event) => {
            const button = event.target.closest("button[data-shop-buy]");
            if (button && typeof buyShopItem === "function") { buyShopItem(button.dataset.shopBuy); return; }
            const enchant = event.target.closest("button[data-shop-enchant]");
            if (enchant && typeof enchantInventoryItem === "function") {
              enchantInventoryItem();
            }
          });
        }
        if (els.talentsList?.addEventListener) {
          els.talentsList.addEventListener("click", (event) => {
            const button = event.target.closest("button[data-talent]");
            if (!button) return;
            const idx = Number.parseInt(button.dataset.member, 10);
            if (typeof spendTalentPoint === "function") spendTalentPoint(idx, button.dataset.talent);
          });
        }
        if (els.markersModal?.addEventListener) {
          els.markersModal.addEventListener("click", (event) => {
            const drop = event.target.closest("button[data-marker-kind]");
            if (drop && typeof dropMapMarker === "function") {
              dropMapMarker(drop.dataset.markerKind);
              return;
            }
            const clear = event.target.closest("button[data-marker-clear]");
            if (clear && typeof clearMapMarkerHere === "function") {
              clearMapMarkerHere();
            }
          });
        }
        if (els.mapZoomIn?.addEventListener) {
          els.mapZoomIn.addEventListener("click", (event) => {
            event.preventDefault();
            event.stopPropagation();
            zoomMap(0.25);
          });
        }
        if (els.mapZoomOut?.addEventListener) {
          els.mapZoomOut.addEventListener("click", (event) => {
            event.preventDefault();
            event.stopPropagation();
            zoomMap(-0.25);
          });
        }
        if (els.mapZoomReset?.addEventListener) {
          els.mapZoomReset.addEventListener("click", (event) => {
            event.preventDefault();
            event.stopPropagation();
            resetMapZoom();
          });
        }
        // Ctrl/⌘ + wheel zooms the map on desktops.
        if (els.mapScroller?.addEventListener) {
          els.mapScroller.addEventListener("wheel", (event) => {
            if (!event.ctrlKey && !event.metaKey) return;
            event.preventDefault();
            zoomMap(event.deltaY < 0 ? 0.25 : -0.25);
          }, { passive: false });
          // Pinch zoom: track two-finger touch movement.
          let pinchStartDistance = 0;
          let pinchStartZoom = 1;
          els.mapScroller.addEventListener("touchstart", (event) => {
            if (event.touches.length !== 2) return;
            const a = event.touches[0];
            const b = event.touches[1];
            pinchStartDistance = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
            pinchStartZoom = state.mapZoom || 1;
          }, { passive: true });
          els.mapScroller.addEventListener("touchmove", (event) => {
            if (event.touches.length !== 2 || !pinchStartDistance) return;
            const a = event.touches[0];
            const b = event.touches[1];
            const distance = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
            const ratio = distance / pinchStartDistance;
            setMapZoom(pinchStartZoom * ratio);
          }, { passive: true });
        }
        if (els.saveSlotList?.addEventListener) {
          els.saveSlotList.addEventListener("click", (event) => {
            const button = event.target.closest("button[data-save-slot]");
            if (!button) return;
            if (typeof setActiveSlot === "function") setActiveSlot(button.dataset.saveSlot);
            els.saveSlotsModal?.classList.add("hidden");
            render();
          });
        }

        if (els.characterCreateList?.addEventListener) {
          els.characterCreateList.addEventListener("change", (event) => {
            const select = event.target.closest("select[data-member-index]");
            if (!select) return;
            const index = Number.parseInt(select.dataset.memberIndex, 10);
            const member = state.party[index];
            if (!member || state.characterCreated) return;
            member.classKey = select.value;
            member.signatureCooldown = 0;
            // New class → that class's default portrait.
            member.portraitKey = null;
            renderCharacterCreate();
          });
        }
        if (els.characterCreateList?.addEventListener) {
          els.characterCreateList.addEventListener("click", (event) => {
            const button = event.target?.closest?.("button[data-portrait-for]");
            if (!button) return;
            const member = state.party[Number.parseInt(button.dataset.portraitFor, 10)];
            if (!member || typeof cycleMemberPortrait !== "function") return;
            cycleMemberPortrait(member);
            renderCharacterCreate();
          });
        }
        if (els.characterCreateGameMode?.addEventListener) {
          if (typeof getGameModeDefinitions === "function" && typeof els.characterCreateGameMode.replaceChildren === "function" && typeof document.createElement === "function") {
            const options = getGameModeDefinitions().map((mode) => {
              const option = document.createElement("option");
              option.value = mode.key;
              option.textContent = mode.name;
              if (mode.key === (state.gameMode || "standard")) option.selected = true;
              return option;
            });
            if (options.every((o) => o && typeof o.value !== "undefined")) {
              els.characterCreateGameMode.replaceChildren(...options);
            }
          }
          const syncModeUi = () => {
            const selected = els.characterCreateGameMode.value;
            if (typeof setGameMode === "function") setGameMode(selected);
            if (els.gameModeHelp && typeof currentGameMode === "function") {
              els.gameModeHelp.textContent = currentGameMode().summary;
            }
          };
          els.characterCreateGameMode.addEventListener("change", syncModeUi);
          syncModeUi();
        }
        if (els.characterCreateDifficulty?.addEventListener) {
          els.characterCreateDifficulty.addEventListener("change", () => {
            if (typeof setDifficulty === "function") setDifficulty(els.characterCreateDifficulty.value);
          });
        }
        if (els.characterCreateDeity?.addEventListener) {
          // Populate the patron list from the pantheon so new gods need no HTML.
          if (typeof getDeityDefinitions === "function" && typeof els.characterCreateDeity.replaceChildren === "function" && typeof document.createElement === "function") {
            const options = getDeityDefinitions().map((god) => {
              const option = document.createElement("option");
              option.value = god.key;
              option.textContent = god.name;
              if (god.key === "none") option.selected = true;
              return option;
            });
            if (options.every((o) => o && typeof o.value !== "undefined")) {
              els.characterCreateDeity.replaceChildren(...options);
            }
          }
          els.characterCreateDeity.addEventListener("change", () => {
            if (typeof setDeity === "function") setDeity(els.characterCreateDeity.value);
          });
        }
        if (els.characterCreateDaily?.addEventListener) {
          els.characterCreateDaily.addEventListener("change", () => {
            state.dailySeed = els.characterCreateDaily.checked && typeof dailySeed === "function" ? dailySeed() : null;
          });
        }
        if (els.characterCreateStart?.addEventListener) {
          els.characterCreateStart.addEventListener("click", () => {
            // beginRun applies the on-screen selections (classes, difficulty,
            // deity, daily) that the change handlers already wrote into state,
            // builds the world, and hides the modal. Shared with the URL/CLI
            // startup options.
            if (typeof beginRun === "function") beginRun();
            render();
          });
        }
        if (els.characterCreateRandom?.addEventListener) {
          els.characterCreateRandom.addEventListener("click", () => {
            if (state.characterCreated) {
              setMessage("Class actions are fixed for this run. Start a new expedition to choose another party.");
              return;
            } else {
              state.message = "Choosing the starting party's classes and fixed actions.";
            }
            const klasses = typeof getClassDefinitions === "function" ? getClassDefinitions() : [];
            for (const member of state.party) {
              member.classKey = klasses[Math.floor(Math.random() * klasses.length)]?.key || member.classKey;
            }
            renderCharacterCreate();
          });
        }
        if (els.dialogueChoices?.addEventListener) {
          els.dialogueChoices.addEventListener("click", (event) => {
            const button = event.target.closest("button[data-dialogue-idx]");
            if (!button) return;
            const idx = Number.parseInt(button.dataset.dialogueIdx, 10);
            const choices = context.dialogueChoices || [];
            const choice = choices[idx];
            hideDialogue();
            if (choice?.onSelect) choice.onSelect();
          });
        }
        for (const name of ["helpModal", "legendModal", "settingsModal", "achievementsModal", "historyModal", "characterModal", "talentsModal", "markersModal", "saveSlotsModal", "shopModal", "dialogueModal", "moreActionsModal", "bestiaryModal", "questsModal", "statsModal"]) {
          const modal = els[name];
          if (modal?.addEventListener) {
            modal.addEventListener("click", (event) => {
              if (event.target === modal) hideAllModals();
            });
          }
        }
        if (els.settingsModal) {
          const settings = typeof readSettings === "function" ? readSettings() : {};
          const tilesetSelect = document.getElementById("settingTileset");
          const runModeCheck = document.getElementById("settingRunMode");
          const highContrastCheck = document.getElementById("settingHighContrast");
          const hideFlashCheck = document.getElementById("settingHideFlash");
          if (tilesetSelect) {
            const tileset = typeof normalizeTileset === "function"
              ? normalizeTileset(settings.tileset)
              : settings.tileset === "linocut" ? "linocut" : "classic";
            tilesetSelect.value = tileset;
            if (typeof setTileset === "function") setTileset(tileset);
            else state.tileset = tileset;
            tilesetSelect.addEventListener("change", () => {
              const selected = typeof normalizeTileset === "function"
                ? normalizeTileset(tilesetSelect.value)
                : tilesetSelect.value === "linocut" ? "linocut" : "classic";
              settings.tileset = selected;
              if (typeof setTileset === "function") setTileset(selected);
              else state.tileset = selected;
              writeSettings(settings);
              renderViewport();
            });
          }
          if (runModeCheck) {
            runModeCheck.checked = !!settings.runMode;
            state.runMode = !!settings.runMode;
            runModeCheck.addEventListener("change", () => {
              settings.runMode = runModeCheck.checked;
              state.runMode = runModeCheck.checked;
              writeSettings(settings);
            });
          }
          if (highContrastCheck) {
            highContrastCheck.checked = !!settings.highContrast;
            if (settings.highContrast) document.body.classList?.add("high-contrast");
            highContrastCheck.addEventListener("change", () => {
              settings.highContrast = highContrastCheck.checked;
              document.body.classList?.toggle?.("high-contrast", highContrastCheck.checked);
              writeSettings(settings);
            });
          }
          if (hideFlashCheck) {
            hideFlashCheck.checked = !!settings.hideFlash;
            if (settings.hideFlash) document.body.classList?.add("hide-crit-flash");
            hideFlashCheck.addEventListener("change", () => {
              settings.hideFlash = hideFlashCheck.checked;
              document.body.classList?.toggle?.("hide-crit-flash", hideFlashCheck.checked);
              writeSettings(settings);
            });
          }
          const hapticsCheck = document.getElementById("settingHaptics");
          if (hapticsCheck) {
            hapticsCheck.checked = settings.haptics !== false;
            hapticsCheck.addEventListener("change", () => {
              settings.haptics = hapticsCheck.checked;
              writeSettings(settings);
            });
          }
          const soundCheck = document.getElementById("settingSound");
          if (soundCheck) {
            soundCheck.checked = settings.sound !== false;
            soundCheck.addEventListener("change", () => {
              settings.sound = soundCheck.checked;
              writeSettings(settings);
              if (soundCheck.checked && typeof resumeAudio === "function") resumeAudio();
            });
          }
          const autoPickupCheck = document.getElementById("settingAutoPickup");
          if (autoPickupCheck) {
            autoPickupCheck.checked = state.autoPickup !== false;
            autoPickupCheck.addEventListener("change", () => {
              state.autoPickup = autoPickupCheck.checked;
              if (typeof saveGame === "function") saveGame();
            });
          }
          const colorblindCheck = document.getElementById("settingColorblind");
          if (colorblindCheck) {
            colorblindCheck.checked = !!settings.colorblind;
            if (settings.colorblind) document.body.classList?.add("colorblind");
            colorblindCheck.addEventListener("change", () => {
              settings.colorblind = colorblindCheck.checked;
              document.body.classList?.toggle?.("colorblind", colorblindCheck.checked);
              writeSettings(settings);
            });
          }
        }
        // First-launch flow: character creation supersedes the welcome screen.
        if (!state.characterCreated && els.characterCreateModal) {
          showModal("characterCreateModal");
        }

        window.addEventListener("keydown", (event) => {
          if (event.key === "Escape") {
            if (els.helpModal && !els.helpModal.classList.contains("hidden")) {
              event.preventDefault();
              hideHelpModal();
              return;
            }
          }
          if (event.key === "?") {
            event.preventDefault();
            toggleHelpModal();
            return;
          }

          const inventoryIndex = inventoryIndexForKey(event.key);
          if (inventoryIndex >= 0) {
            const item = state.inventory[inventoryIndex];
            if (!item) return;
            event.preventDefault();
            useItem(item.id);
            return;
          }

          // Inventory sort + filter toggles
          if (event.key === "[") {
            event.preventDefault();
            const next = cycleInventorySort();
            setMessage(`Inventory sort: ${next}.`);
            render();
            return;
          }
          if (event.key === "]") {
            event.preventDefault();
            const next = cycleInventoryFilter();
            setMessage(`Inventory filter: ${next}.`);
            render();
            return;
          }

          const keyMap = {
            ArrowLeft: "turnLeft",
            a: "turnLeft",
            A: "turnLeft",
            ArrowRight: "turnRight",
            d: "turnRight",
            D: "turnRight",
            q: "moveLeft",
            Q: "moveLeft",
            e: "moveRight",
            E: "moveRight",
            ArrowUp: "moveForward",
            w: "moveForward",
            W: "moveForward",
            ArrowDown: "moveBack",
            s: "moveBack",
            S: "moveBack",
            " ": "attack",
            ">": "interact",
            "<": "interact",
            Enter: "interact",
            u: "interact",
            U: "interact",
            ",": "pickup",
            g: "pickup",
            G: "pickup",
            x: "disarm",
            X: "disarm",
            ".": "wait",
            r: "wait",
            "5": "rest",
            R: "rest",
            o: "autoExplore",
            O: "autoExplore",
            t: "travelToStairs",
            T: "travelToStairs",
            z: "travelToLoot",
            Z: "travelToLoot",
            f: "cycleFormation",
            F: "cycleFormation",
            c: "charge",
            C: "charge",
            y: "sweep",
            Y: "sweep",
            p: "dropItem",
            P: "dropItem",
            i: "examine",
            I: "examine",
            l: "legend",
            L: "legend",
            b: "signature",
            B: "signature",
            v: "ultimate",
            V: "ultimate",
            k: "character",
            K: "character",
            n: "search",
            N: "search",
            j: "talents",
            J: "talents",
            m: "markers",
            M: "markers"
          };
          const action = keyMap[event.key];
          if (!action) return;
          event.preventDefault();
          if (dispatchUiAction(action)) return;
          handleAction(action);
        });

        if ("ResizeObserver" in window) {
          const viewportObserver = new ResizeObserver(() => renderViewport());
          viewportObserver.observe(els.viewport);
        } else {
          window.addEventListener("resize", () => renderViewport());
        }

      }
      Object.assign(context, {
        bindInput,
        bindSidebarAccordion,
        dispatchUiAction,
        pollStandardGamepad,
      });
    }
  };
}());
