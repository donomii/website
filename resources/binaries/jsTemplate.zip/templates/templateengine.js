//Copywrite Jeremy Price
//All rights reserved

function DonomiTemplateEngine(){

	this.convert = function () {
		var html = document.getElementById('markdown').innerHTML;
		
		var converter = new Attacklab.showdown.converter();
		var converted = converter.makeHtml(html);

		var adiv = document.createElement("div");
		adiv.innerHTML=converted;
		$('#markdown').replaceWith(adiv);
		//document.getElementById('markdown').innerHTML=converted;
	}

	this.start = function () {
		jQuery.get('../templates/simplebeauty/template.html', function(data) {

			var content = document.getElementById('content');

			var range = document.createRange();
			range.selectNode(document.body);
			var parsedHTML = range.createContextualFragment(data);
			document.body.appendChild(parsedHTML)
			var targetwrapper = document.getElementById('main_content');
			var targ = document.getElementById('target');

			targetwrapper.replaceChild(content,targ); 



		});
	this.convert();

}


}
TemplateEngine = new DonomiTemplateEngine();
